/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luong_7_testing_dungeon;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

/**
 *
 * @author mluong
 */
public class Orb {
    private int locationX, width, height;  //keep private so varaibles don't interfere
    private int locationY;  //get rid of static because it will set for every single orb the same
    private boolean isVisible; 
    private int dmg, hitboxX, hitboxY;
    private Image orb;
    public Shape hitbox;
    private int timer;
    private int direction;
    
    //class constructor, values for objects are passed here.
    public Orb(int x, int y) throws SlickException {
        this.isVisible = false;
        this.locationX = x;
        this.locationY = y;
        this.orb = new Image ("res/orbs/Ninja_12.png");
        this.hitbox = new Rectangle (locationX, locationY, 32, 32);
        this.timer = 0;
    }
    
    public void settimer(int t){
        this.timer = t;
    }

    public int gettimer(){

	return this.timer;
    }

     public void countdown(){
	this.timer--;
    }


    public Image getOrb() {
        return orb;
    }

    public void setOrb(Image orb) {
        this.orb = orb;
    }

    public Shape getHitbox() {
        return hitbox;
    }

    public void setHitbox(Shape hitbox) {
        this.hitbox = hitbox;
    }

    public int getLocationX() {
        return locationX;
    }

    public void setLocationX(int locationX) {
        this.locationX = locationX;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getLocationY() {
        return locationY;
    }

    public void setLocationY(int locationY) {
        this.locationY = locationY;
    }

    public boolean isIsVisible() {
        return isVisible;
    }

    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    public int getDmg() {
        return dmg;
    }

    public void setDmg(int dmg) {
        this.dmg = dmg;
    }

    public int getHitboxX() {
        return hitboxX;
    }

    public void setHitboxX(int hitboxX) {
        this.hitboxX = hitboxX;
    }

    public int getHitboxY() {
        return hitboxY;
    }

    public void setHitboxY(int hitboxY) {
        this.hitboxY = hitboxY;
    }

    public void setDirection(int i){
	this.direction = i;
    }
    public int getDirection(){
        return this.direction;
    }

   
    
    
    /**
      *  Getters and setters are a common concept in java. 
      *  A design guideline oin Java, and object oriented
      *  program in general, is to encapsulate/isolate
      *  values as much as possibe.
      *  Getters - are methods used to query the values of
      *  instance variables
      *  this.getlocationX(); // this is a getter returns a value 
      *  Setters - methods that set values for instance
      *  variables
      *  orb1.setLocation(Player.x, Player.y
    */
    
    
}
