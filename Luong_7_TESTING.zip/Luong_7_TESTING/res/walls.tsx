<?xml version="1.0" encoding="UTF-8"?>
<tileset name="walls" tilewidth="32" tileheight="32" tilecount="1">
 <image source="0021_floor_default.bmp" width="32" height="32"/>
 <tile id="0">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
