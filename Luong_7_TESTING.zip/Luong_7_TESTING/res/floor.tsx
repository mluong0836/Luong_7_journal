<?xml version="1.0" encoding="UTF-8"?>
<tileset name="floor" tilewidth="32" tileheight="32" tilecount="1">
 <tile id="0">
  <image width="32" height="32" source="1024x768.png"/>
 </tile>
</tileset>
